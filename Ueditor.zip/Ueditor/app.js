

let html = document.getElementById("html");
let css = document.getElementById('css');
let js = document.getElementById('js');
let editor = document.getElementById("editor");
let output = document.getElementById('output');
let outputbtn = document.getElementById('output-btn');
let container = document.getElementById('editorContainer');
let result = document.getElementsByClassName('showOutput');
let html_editor = document.getElementById('html_editor');

function load() {

  var x = CodeMirror.fromTextArea
        (document.getElementById('editor_text'), {
            mode: "xml",
            theme: "monokai",
            lineNumbers: true,
            matchBrackets: true,
            autoCloseTags: true
            
        });
        x.setValue(`<!DOCTYPE html>
<html>
  <head>
  </head>

  <body>
    <p>first paragraph</p>
  </body>

</html>`,1);
        x.setSize("592.8", "425");

 //alert('testing')
}
html.addEventListener('click', function () {

   
    //editor.innerText = 'html working';
   // alert('working');
})

css.addEventListener('click', function () {
 

  var y = CodeMirror.fromTextArea

        (document.getElementById('editor_text'), {
            mode: "xml",
            theme: "monokai",
            lineNumbers: true,
            matchBrackets: true,
            autoCloseTags: true
            
        });
        y.setValue(`body { }`, 1);

    //editor.innerText = 'css working';
   
})

js.addEventListener('click', function () {

    

    editor.innerText ='js working'
   // alert('working');
})

outputbtn.addEventListener('click', function () {

    //editor.innerText = "out display";

    const mq = window.matchMedia("(max-width: 960px)");

    if (mq.matches) {
        
        editor.style.display = 'none';
        container.classList.toggle('showOutput');
        //outputbtn.style.backgroundColor = 'yellow';
    } 

})
